function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6eh0d8H2Jzc":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

