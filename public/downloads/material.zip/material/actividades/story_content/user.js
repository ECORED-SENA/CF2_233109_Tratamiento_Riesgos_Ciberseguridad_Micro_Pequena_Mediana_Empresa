function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5zUQSBlIs3F":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

